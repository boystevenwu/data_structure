#include "LLQueue.hpp"
#include "proj2.hpp"

int main()
{

    return 0;
}
